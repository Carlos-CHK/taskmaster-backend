Umieść tutaj dokumentację (PDF/UML/screenshoty).
