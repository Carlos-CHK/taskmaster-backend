package com.taskmaster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskMasterApplication {
    public static void main(String[] args) {
        SpringApplication.run(TaskMasterApplication.class, args);
    }
}
