package com.taskmaster;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskMasterApplicationTests {

    @Test
    void contextLoads() {
        // podstawowy test szkieletowy – potwierdza uruchomienie kontekstu Spring
    }
}
