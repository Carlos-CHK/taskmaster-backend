# TaskMaster (TEP)

TaskMaster to aplikacja webowa służąca do zarządzania zadaniami w zespołach projektowych (uproszczony klon Trello/Jira).
System umożliwia użytkownikom tworzenie zadań, przypisywanie ich do członków zespołu oraz śledzenie postępu prac
(zmiana statusów TODO / IN_PROGRESS / DONE).

## Wymagania
- Java 17
- Maven
- Docker + Docker Compose (opcjonalnie)

## Jak uruchomić (lokalnie)
1. Zbuduj projekt:
```bash
mvn clean package
```

2. Uruchom aplikację (bez Dockera):
```bash
java -jar target/taskmaster-0.0.1-SNAPSHOT.jar
```

Aplikacja będzie dostępna pod: http://localhost:8080

## Jak uruchomić (Docker Compose)
1. Zbuduj projekt:
```bash
mvn clean package
```

2. Uruchom kontenery:
```bash
docker compose up --build
```

Aplikacja: http://localhost:8080  
Baza danych (PostgreSQL): localhost:5432

## Dokumentacja
Pliki dokumentacji (PDF/UML/screenshoty) trzymaj w katalogu `docs/`.

## Raport pokrycia testami (JaCoCo)
Aby wygenerować raport HTML:
```bash
mvn test
```
Raport znajdziesz w: `target/site/jacoco/index.html`
